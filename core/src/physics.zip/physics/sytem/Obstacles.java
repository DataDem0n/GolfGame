package physics.sytem;

public interface Obstacles {
    public double [] collide(double [] coordsAndVelocity, double[] tempCoordinates) ;
}
