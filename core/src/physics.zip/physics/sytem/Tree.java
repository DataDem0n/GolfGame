package physics.sytem;

public class Tree implements Obstacles{

    private double coordX;
    private double coordY;
    private final double radius = 2;

    public Tree(double coordX, double coordY) {
        this.coordX = coordX;
        this.coordY = coordY;
    }
    @Override
    public double[] collide(double[] coordsAndVelocity,  double[] tempCoordinates) {
        if((Math.pow(radius ,2)>(Math.pow((coordY -coordsAndVelocity[0]), 2 )+Math.pow((coordY-coordsAndVelocity[1]), 2 ))))
        {
            coordsAndVelocity[0] = tempCoordinates[0];
            coordsAndVelocity[1] = tempCoordinates[1];
            coordsAndVelocity[2]=0;
            coordsAndVelocity[3]=0;
            System.out.println("you hit the tree!!!");
        }
        return coordsAndVelocity;
    }
}
