package physics.sytem;



public interface DifferentTerrain {

    public void change(double [] coordsAndVelocity, double [] tempCoordinates);
}
